﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataBase
{
    class AccountInfo
    {
        /*public static String dbPuth = "Provider=Microsoft.ACE.OLEDB.12.0;" + @"Data Source=.//data/Game.accdb";
        public static String PersonLogin;
        public static String PersonPass;
        public static int PersonID;
        public static String ImagePath;*/

    }
}
